package com.cg.parallel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.parallel.beans.Account;
import com.cg.parallel.beans.Transaction;
import com.cg.parallel.exception.AccountNotFoundException;
import com.cg.parallel.service.BankService;

@RestController
public class BankController {
	@Autowired
	private BankService Service;

	@PostMapping("/createaccount")
	public List<Account> addAccount(@RequestBody Account account) {
		return Service.createAcccount(account);
	}

	@GetMapping("/allaccounts")
	public List<Account> getAllAccounts() {
		return Service.getAllAccounts();
	}

	@GetMapping("/deposit")
	public List<Account> deposit(@RequestParam int accNum, @RequestParam double amount)
			throws AccountNotFoundException {

		return Service.deposit(accNum, amount);
	}

	@GetMapping("/withdraw")
	public List<Account> withdraw(@RequestParam int accNum, @RequestParam double amount)
			throws AccountNotFoundException {

		return Service.withdraw(accNum, amount);
	}

	@GetMapping("/transfer")
	public List<Account> fundsTransfer(@RequestParam int accNo1, @RequestParam int accNo2, @RequestParam double amount)
			throws AccountNotFoundException {
		return Service.fundsTransfer(accNo1, accNo2, amount);

	}

	@GetMapping("/transactions")
	public List<Transaction> getAllTransactions() {
		return Service.getAllTransactions();

	}

	@GetMapping("/balance/{accNum}")
	public double getBalance(@PathVariable int accNum) throws AccountNotFoundException {
		return Service.getInitialBalance(accNum);
	}

	@GetMapping("/get")
	public List<Transaction> getTransactionByAccno(@RequestParam int accNum) {
		return Service.getTransactionByAccno(accNum);

	}

}
