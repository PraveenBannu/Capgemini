package com.cg.parallel.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.parallel.beans.Account;

public interface AccountRepository extends JpaRepository<Account, Integer> {

}
