package com.cg.parallel.service;

import java.util.List;

import com.cg.parallel.beans.Account;
import com.cg.parallel.beans.Transaction;
import com.cg.parallel.exception.AccountNotFoundException;


public interface BankService {
	
	List<Account> createAcccount(Account acc);

	List<Account> getAllAccounts();
	

	List<Account> deposit(int accNum, double amount) throws AccountNotFoundException;

	List<Account> withdraw(int accNum, double amount) throws  AccountNotFoundException;

	List<Account> fundsTransfer(int accNo1, int accNo2, double amount) throws AccountNotFoundException;
	
	List<Transaction> getAllTransactions();

	double getInitialBalance(int accNum) throws AccountNotFoundException;

	List<Transaction> getTransactionByAccno(int accNum);
	
	


}
