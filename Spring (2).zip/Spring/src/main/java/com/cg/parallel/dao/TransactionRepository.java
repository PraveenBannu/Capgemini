package com.cg.parallel.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.parallel.beans.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Integer> {

	@Query("from Transaction where ACCOUNT_ACCNO=:accno")
	List<Transaction> getTransactionByAccno(@Param("accno") int accNum);
}
