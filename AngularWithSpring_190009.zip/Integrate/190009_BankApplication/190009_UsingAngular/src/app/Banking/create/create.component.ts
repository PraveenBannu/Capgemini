import { Component, OnInit } from '@angular/core';
import { Account } from 'src/app/Entity/Account';
import { Transactions } from 'src/app/Entity/Transactions';
import { Router } from '@angular/router';
import { BankService } from 'src/app/Service/bank.service';

@Component({
  selector: 'create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  createdAccount: Account;
  createdTransaction: Transactions;
  createdFlag: boolean = false;
  router: Router;
  service: BankService;

  constructor(service: BankService, router: Router) {
    this.service = service;
    this.router = router;
  }


  add(data: any) {
    data.accBal = 1000;
    this.createdAccount = new Account(data.accNum, data.accName, data.accPh, data.accPass, data.accAdd, data.accBal);
    var add = this.service.add(this.createdAccount);
    add.subscribe((data) => {
      console.log(data)
      alert("Created Account!!!\n Your Account No. is : " + data.accNo);
      this.service.accounts.push(data)
    })


    this.createdFlag = true;
    setTimeout(() => {
      this.router.navigate(['banking']);
    }, 10000)

  }

  ngOnInit() {
  }

}
