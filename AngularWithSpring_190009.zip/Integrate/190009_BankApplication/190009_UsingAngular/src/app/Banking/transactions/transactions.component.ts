import { Component, OnInit } from '@angular/core';
import { Transactions } from 'src/app/Entity/Transactions';
import { Account } from 'src/app/Entity/Account';
import { BankService } from 'src/app/Service/bank.service';
import { Router } from '@angular/router';

@Component({
  selector: 'transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  transactions:Transactions[]=[];
  accounts:Account[]=[];
  service:BankService;
  router:Router;

  constructor(service:BankService,router:Router) 
  { 
    this.service=service;
    this.router=router;
  }

  showTransactions(data:any)
  {
    var tra = this.service.showTransactions(data.accNum);
    tra.subscribe( (data)=>{
      this.transactions=data;
    })
    setTimeout(() => {
      this.router.navigate(['home']);
    }, 15000);
  }

  ngOnInit() 
  {
    this.service.fetchTransactions();
    // this.accounts=this.service.getAccounts();
  }
}
