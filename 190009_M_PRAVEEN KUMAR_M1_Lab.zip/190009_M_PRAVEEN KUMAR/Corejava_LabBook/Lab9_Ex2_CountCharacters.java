package capgemini.labbook;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Lab9_Ex2_CountCharacters {
	private static Map<Character, Integer> countCharacter(char[] ch) {
		HashMap<Character, Integer> hm = new HashMap<Character, Integer>();
		for (char c : ch) {
			if (hm.containsKey(c)) {
				hm.replace(c, hm.get(c) + 1);
			} else
				hm.put(c, 1);
		}
		return hm;
	}
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range and characters");
		int n = sc.nextInt();
		char[] ch = new char[n];
		for (int i = 0; i < n; i++) {
			ch[i] = sc.next().charAt(0);
		}
		System.out.println(countCharacter(ch));
	}
}