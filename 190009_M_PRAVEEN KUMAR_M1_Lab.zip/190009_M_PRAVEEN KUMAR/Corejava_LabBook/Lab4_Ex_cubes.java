package capgemini.labbook;

public class Lab4_Ex_cubes {
	public static int findTheSumOfTheCubes (int n) {
		int s=0;
		while(n!=0) {
			s = s+((n%10)*(n%10)*(n%10));
			n=n/10;
		}
		return s;
	}
	public static void main(String[] args) {
		System.out.println(+findTheSumOfTheCubes(258));
	}
}
