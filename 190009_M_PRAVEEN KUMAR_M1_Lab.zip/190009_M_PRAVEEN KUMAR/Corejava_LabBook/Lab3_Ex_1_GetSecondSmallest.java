package capgemini.labbook;

import java.util.Arrays;

public class Lab3_Ex_1_GetSecondSmallest {
		 
		public static int getSecondSmallest(int[] nums) {
			Arrays.sort(nums);
			return nums[1];
		}
		public static void main(String[] args) {
			int[] nums = {5,14,2,3,6,9,5};
			int result;
			result = getSecondSmallest(nums);
			System.out.println("The get Second Smallest is:"+result);
		}
}
