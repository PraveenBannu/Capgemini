package capgemini.labbook;

import com.cg.eis.exception.EmployeeException;

public class Lab5_Ex6_EmployeeSalary {
	public static void main(String[] args) {
		String name = "Praveen";
		int empId = 101;
		float salary = 20000f;
		try {
			if (salary < 3000)
				throw new EmployeeException("Salary is below 3000");
			else
				System.out.println("Name : " + name + ", EmpId : " + empId + ", salaray : " + salary);
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
