package capgemini.labbook;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Lab8_Ex3_FileCount {

	public static void main(String[] args) {

		File file = new File("C:\\capgemini\\Praveen\\Lab8_Ex3_File.txt");

		// To display no of lines

		try {
			int charCount = 0, lineCount = 0, wordCount = 0;
			FileReader fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String s = bufferedReader.readLine();
			while (s != null) {
				// To count no of lines
				lineCount++;
				String[] words = s.split(" ");
				// To count no of words
				// System.out.println(Arrays.toString(words));
				wordCount += words.length;
				// To count no of characters
				for (String word : words) {
					charCount += word.length();
				}
				s = bufferedReader.readLine();
			}
			bufferedReader.close();
			System.out.println("Character Count " + charCount);
			System.out.println("Word Count " + wordCount);
			System.out.println("Line Count " + lineCount);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}