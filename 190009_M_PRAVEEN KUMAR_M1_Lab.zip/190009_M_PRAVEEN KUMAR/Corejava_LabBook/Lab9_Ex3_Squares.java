package capgemini.labbook;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Lab9_Ex3_Squares {
    public static Map<Integer, Integer> getSquares(int[] arr) {
        HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();


        for (int i : arr) {
            hm.put(i, i * i);
        }
        return hm;
    }
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the range and array elements");
        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        System.out.println(getSquares(arr));
        sc.close();
    }
}
