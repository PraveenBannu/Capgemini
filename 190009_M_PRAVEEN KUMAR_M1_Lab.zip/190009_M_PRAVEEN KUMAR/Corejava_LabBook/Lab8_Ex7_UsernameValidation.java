package capgemini.labbook;

import java.util.Scanner;

public class Lab8_Ex7_UsernameValidation {
	
	public static boolean validateUsername(String username){
		if(!username.endsWith("_job"))
			return false;
		if(username.length()-4 < 8)
			return false;
		return true;
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Username :");
		String username = scan.next();
		System.out.println("Enter Password :");
		@SuppressWarnings("unused")
		String password = scan.next();
		if(validateUsername(username))
			System.out.println("Valid");
		else
			System.out.println("Invalid");
		scan.close();
	}
}