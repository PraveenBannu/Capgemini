package capgemini.labbook;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Lab8_Ex6_CurrentDate {

	public static void DateDifference(String date1, String date2) {

		try {
			Date startDate = new SimpleDateFormat("yyyy-MM-dd").parse(date1);

			Date endDate = new SimpleDateFormat("yyyy-MM-dd").parse(date2);
			long differmilli = endDate.getTime() - startDate.getTime();
			long days = TimeUnit.MILLISECONDS.toDays(differmilli) % 365;// TimeUnit.MILLISECONDS.toHours(duration);
			int year = (int) (differmilli / (1000 * 60 * 60 * 24 * 365)) / 365;
			System.out.println("Difference is-->>");
			System.out.println(year + "Years and" + " " + days + "Days");

		} catch (ParseException e) {

			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		String date2;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a date in formate yyyy-MM-dd");
		String date1;
		// Input
		date2 = scan.nextLine();
		// DateTimeFormatter formatter= DateTimeFormatter.ofPattern("yyyy-MM-dd
		// ");
		// LocalDateTime today= LocalDateTime.now();
		// date1=formatter.format(today);
		// System.out.println(date1);
		date1 = "1998-07-21";
		DateDifference(date1, date2);
		scan.close();

	}

}
