package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeServiceInterface {
	public Employee insuranceScheme(Employee e);
	public String designation(Employee e);
}
