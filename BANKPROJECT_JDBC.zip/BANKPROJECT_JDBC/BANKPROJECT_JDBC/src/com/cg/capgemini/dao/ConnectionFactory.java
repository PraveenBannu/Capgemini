package com.cg.capgemini.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

	private final static String URL = "jdbc:oracle:thin:@localhost:1521/xe";
	private final static String USERNAME = "INVENTORY1";
	private final static String PASSWORD = "INVENTORY1";
	private final static String DRIVER = "oracle.jdbc.driver.OracleDriver";

	private static ConnectionFactory connectionFactory = null;

	private ConnectionFactory() {
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static ConnectionFactory getInstance() {
		if (connectionFactory != null)
			return connectionFactory;
		else
			return new ConnectionFactory();
	}

	public Connection getConnection() {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

}
