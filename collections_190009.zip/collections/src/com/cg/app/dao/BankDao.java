package com.cg.app.dao;

import com.cg.app.bean.Account;

public interface BankDao {
	
	public Account checkAccount(long accNo);

	public void setData(long accNo, Account account);


}
