package com.cg.app.dao;

import java.util.HashMap;

import com.cg.app.bean.Account;

public class BankDaoImpl implements BankDao{
	
	HashMap h1;
	
	public BankDaoImpl(){
		h1=new HashMap();
	}
	
	Account account=new Account();
	

	@Override
	public Account checkAccount(long accNo) {

		if (h1.containsKey(accNo)) {

			account = (Account) h1.get(accNo);
			return account;

		} else

			return null;
	}

	@Override
	public void setData(long accNo, Account account) {
		h1.put(accNo, account);
		
	}

}
