package com.cg.app.exceptions;

public class AccountAlreadyExistsException extends Exception {
	
	public AccountAlreadyExistsException(){
		
	}
	
	@Override
	public String toString(){
		return "Account already exists";
		
	}

}
