package com.cg.app.exceptions;

public class MinimumBalanceException extends Exception{
	
	public MinimumBalanceException(){
		
	}
	
	@Override
	public String toString(){
		return "Minimum Balance should be 1000 rupees";
	}

}
