package com.cg.app.service;

import com.cg.app.bean.Account;
import com.cg.app.dao.BankDao;
import com.cg.app.dao.BankDaoImpl;
import com.cg.app.exceptions.AccountAlreadyExistsException;
import com.cg.app.exceptions.AccountNotFoundException;
import com.cg.app.exceptions.LowBalanceException;



public class BankServiceImpl implements BankService{
	
	BankDao dao=new BankDaoImpl();
	Account account=new Account();
	Account account1=new Account();
	boolean result;
	

	@Override
	public boolean createAccount(String name, String add, long accNo, String phone, int pin, int bal)
			throws AccountAlreadyExistsException {
		/*Account account = new Account();*/
		boolean res = false;

		if (dao.checkAccount(accNo) == null) {

			account.setAccNo(accNo);
			account.setAddress(add);
			account.setBalance(bal);
			account.setName(name);
			account.setPhoneNo(phone);
			account.setPin(pin);
			account.setTrans("Account Created with Balance  : " + bal + "\n");

			dao.setData(accNo, account);

			res = true;
		}

		else

		{
			res = false;
			throw new AccountAlreadyExistsException();
		}
		return res;

	}


	@Override
	public int showBalance(long accNo) throws AccountNotFoundException {
		account = dao.checkAccount(accNo);
		int balance = 0;
		if (account == null) {
			throw new AccountNotFoundException();
		} else {
			balance = account.getBalance();
		}

		return balance;
	}

	@Override
	public int deposit(long accNo, int deposit_amount) throws AccountNotFoundException {
		int balance = 0;
		account = dao.checkAccount(accNo);

		if (account == null) {
			throw new AccountNotFoundException();
		} else {

			balance = account.setBalance(account.getBalance() + deposit_amount);
			String s = account.getTrans() + "Amount deposited :" + deposit_amount + "\n";
			account.setTrans(s);
			dao.setData(accNo, account);
		}

		return balance;
	}

	@Override
	public int withdraw(long accNo, int withdraw_amount) throws AccountNotFoundException, LowBalanceException {

		int balance = 0;
		account = dao.checkAccount(accNo);
		if (account == null) {
			throw new AccountNotFoundException();
		} else {
			if (account.getBalance() > withdraw_amount) {
				balance = account.setBalance(account.getBalance() - withdraw_amount);
				String s = account.getTrans() + "Amount withdrawn :" + withdraw_amount + "\n";
				account.setTrans(s);
			} else {
				throw new LowBalanceException();
			}
			dao.setData(accNo, account);
		}

		return balance;
	}
	

	@Override
	public boolean transferfund(long accNo, long accNo1, int transfer_amount)
			throws AccountNotFoundException, LowBalanceException {
		account = dao.checkAccount(accNo);

		if (!(account == null)) {

			account1 = dao.checkAccount(accNo1);

			if (!(account1 == null))

			{

				int sender_balance = account.getBalance();

				if (sender_balance > transfer_amount) {
					int reciever_balance = account1.getBalance();

					account.setBalance(sender_balance - transfer_amount);
					account1.setBalance(reciever_balance + transfer_amount);
					String s = account.getTrans() + "Transferred to  :" + accNo1 + " Amount : " + transfer_amount + "\n";
					account.setTrans(s);
					String s1 = account1.getTrans() + "Transferred from  :" + accNo + " Amount : " + transfer_amount
							+ "\n";
					account1.setTrans(s1);
					dao.setData(accNo, account);
					dao.setData(accNo1, account1);
				} else {
					throw new LowBalanceException();
				}
			}

			else {
				throw new AccountNotFoundException();
			}
		} else {
			throw new AccountNotFoundException();
		}

		return true;
	}


	@Override
	public boolean validateBalance(long accNo, int amount) throws LowBalanceException {
		account = dao.checkAccount(accNo);
			if (account == null) {
				throw new LowBalanceException();
			} else {
				return true;
			}
		}

	

	@Override
	public String setTrans(long accNo) throws AccountNotFoundException {
		account = dao.checkAccount(accNo);
		String s;

		if (account == null) {
			throw new AccountNotFoundException();
		} else {
			s = account.getTrans();
		}
		return s;
	}
	

}
