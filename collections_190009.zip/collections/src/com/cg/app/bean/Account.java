package com.cg.app.bean;

public class Account {
	
	//fields
	private String name;
	private long accNo;
	private int pin;
	private String address;
	private String phoneNo;
	private int balance;
	
	String trans = new String();

	//default-constructor
	public Account() {
		super();
	}
	
	//parameterized-constructor
	public Account(String name2, int accNo2, int pin2, String dob2, String add2, String phone2, int bal) {
		super();
	}

	//getter and setter methods
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getBalance() {
		return balance;
	}
	public int setBalance(int balance) {
		return this.balance = balance;
	}
	
	
	public String getTrans() {
		return trans;
	}

	public void setTrans(String string) {
		trans = string;
	}

	
	
	

}
