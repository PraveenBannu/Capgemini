package com.cg.cart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cart.beans.Cart;
import com.cg.cart.exception.ProductNotFound;
import com.cg.cart.service.CartService;

@RestController
@CrossOrigin(origins = "http://10.138.151.34:4200")
public class CartController {

	@Autowired
	private CartService cartService;

	@PostMapping("/addtoCart/{productId}/{customerId}")
	public ResponseEntity<?> addToCard(@PathVariable int productId, @PathVariable int customerId) {
		try {
			cartService.addToCart(productId, customerId);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (ProductNotFound e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}

	}

	@GetMapping("/cart/{customerId}")
	public List<Cart> getCart(@PathVariable int customerId) {
		return cartService.getCustomerCart(customerId);
	}

	@DeleteMapping("/cart/{cartId}")
	public ResponseEntity<?> deleteCart(@PathVariable int cartId) {
		cartService.deleteCartItem(cartId);
		return new ResponseEntity<>(HttpStatus.OK);
	}

}
