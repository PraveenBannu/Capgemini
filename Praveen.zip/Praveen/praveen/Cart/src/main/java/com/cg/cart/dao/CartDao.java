package com.cg.cart.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.cart.beans.Cart;
@Repository
public interface CartDao extends JpaRepository<Cart, Integer> {

	@Query("from Cart  where product.productId=:productId AND customerId=:customerId")
	public Cart findbyProduct(@Param("productId") int productId,@Param("customerId") int customerId);
	
	@Query("from Cart  where customerId=:customerId")
	public List<Cart> findAllbyCutomerId(@Param("customerId") int customerId);
	
	
}
