package com.cg.cart.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cart.beans.Cart;
import com.cg.cart.beans.Product;
import com.cg.cart.dao.CartDao;
import com.cg.cart.dao.ProductRepository;
import com.cg.cart.exception.ProductNotFound;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private CartDao cartDao;

	@Override
	public void addToCart(int productId, int customerId) throws ProductNotFound {
		Optional<Product> product = productRepository.findById(productId);
		if (!product.isPresent())
			throw new ProductNotFound();
		else {
			Cart cart1 = cartDao.findbyProduct(productId, customerId);
			if (cart1 == null) {
				Cart cart = new Cart(customerId, product.get(), 1);
				cartDao.save(cart);
			} else {
				cart1.setProductQuantity(cart1.getProductQuantity() + 1);
				cartDao.save(cart1);
			}
		}
	}

	@Override
	public List<Cart> getCustomerCart(int customerId) {
		return cartDao.findAllbyCutomerId(customerId);
	}

	@Override
	public void deleteCartItem(int cartId) {
		cartDao.deleteById(cartId);
	}

}
