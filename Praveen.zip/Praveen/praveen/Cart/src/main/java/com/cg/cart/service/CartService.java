package com.cg.cart.service;

import java.util.List;

import com.cg.cart.beans.Cart;
import com.cg.cart.exception.ProductNotFound;

public interface CartService {

	void addToCart(int productId,int customerId) throws ProductNotFound;
	List<Cart> getCustomerCart(int customerId);
	
	void deleteCartItem(int cartId);
}
