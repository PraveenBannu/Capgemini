package com.cg.cart.exception;

public class ProductNotFound extends Exception  {

	public ProductNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
