import { Component, OnInit } from '@angular/core';
import { CartServiceService } from '../cart-service.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private cartService:CartServiceService) { }
  cart:any[] = [];
  total:number=0;
  ngOnInit() {
    this.cartService.getCart().subscribe(res=>{
      this.cart=res;
      console.log(this.cart);
      this.calculateTotal();
    },error=>{
      alert("failed to fetch data");
    })
  }

  calculateTotal(){
    this.total=0;
    this.cart.forEach(element => {
     
      this.total = this.total+(element.productQuantity*element.product.price);
    });
  }

  delete(cartId){
    this.cartService.deleteCart(cartId).subscribe(res=>{
      alert("Deleted");
      this.ngOnInit();
    },error=>{
      alert("Failed to delete");
    })
  }
}
