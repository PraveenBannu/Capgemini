import { Component, OnInit } from '@angular/core';
import { CartServiceService } from '../cart-service.service';

@Component({
  selector: 'app-productpage',
  templateUrl: './productpage.component.html',
  styleUrls: ['./productpage.component.css']
})
export class ProductpageComponent implements OnInit {


  isAdded = false;

  constructor(private cartService: CartServiceService) { }

  ngOnInit() { }
  addtoCart(id: number) {
    this.cartService.addtocart(id).subscribe(res => {
      console.log(res);
      this.isAdded = true;
    })
  }
}
