import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartServiceService {

  constructor(private http: HttpClient) { }

  baseUri = "http://192.168.0.101:6500/"

  addtocart(productId: number): Observable<any> {
    return this.http.post<any>(this.baseUri + "addtoCart/" + productId + '/' + 1000, null);
  }

  getCart():Observable<any[]>{
    return this.http.get<any[]>(this.baseUri+"cart/"+1000);
  }

  deleteCart(cartId:number):Observable<any>{
    return this.http.delete<any>(this.baseUri+"cart/"+cartId);
  }

}
