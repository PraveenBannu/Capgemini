package paymentDetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"},features="src/test/resources/PaymentDetails",dryRun=false,glue="paymentDetails")
public class TestRunner {

}
