import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';
import { Customer } from '../EntityClasses/Customer';
import { Transaction } from '../EntityClasses/Transaction';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {
bankService:BankServiceService;
CreateBoolean:Boolean=true;
  constructor(bankService:BankServiceService) {
    this.bankService=bankService;
   }

  ngOnInit() {
  }
  createAccount(customer:Customer){
    let AccNo =Math.floor(Math.random()*100)+1000;
    let Balance=500;
    let transID=Math.floor(Math.random()*10)+100;
    
    let transObj=new Transaction(transID,"account Created",AccNo,Balance);
    let customerObj=new Customer(AccNo,customer.Name,customer.PhoneNo,customer.AadharNo,Balance,customer.Pin);
  this.bankService.CreateAccount(customerObj);
  this.bankService.addTransaction(transObj);
  this.CreateBoolean=false;
  }
}
