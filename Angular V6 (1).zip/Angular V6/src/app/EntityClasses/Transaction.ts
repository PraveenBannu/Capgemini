export class Transaction{
    TransactionId:number;
    TransactionType:String;
    AccountNumber:number;
    Amount:number;
    constructor(TransactionId:number,TransactionType:String,AccountNumber:number,Amount:number){
this.TransactionId=TransactionId;
this.TransactionType=TransactionType;
this.AccountNumber=AccountNumber;
this.Amount=Amount;
    }
}