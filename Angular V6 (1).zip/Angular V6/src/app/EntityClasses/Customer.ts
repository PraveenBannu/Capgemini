export class Customer{
    AccNo:number;
    Name:String;
    PhoneNo:number;
    AadharNo:number;
    Balance:number;
    Pin:number;
    constructor(AccNo:number,Name:String,PhoneNo:number,AadharNo:number,Balance:number,Pin:number){
        this.AccNo=AccNo;
        this.Name=Name;
        this.PhoneNo=PhoneNo;
        this.AadharNo=AadharNo;
        this.Balance=Balance;
        this.Pin=Pin;
    }
}