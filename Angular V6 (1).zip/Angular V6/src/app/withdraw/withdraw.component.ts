import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';
import { Customer } from '../EntityClasses/Customer';
import { Transaction } from '../EntityClasses/Transaction';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  bankService:BankServiceService;
  customers:Customer[];
  transactions:Transaction[];
  constructor(bankService:BankServiceService) {
    this.bankService=bankService;
   }

  Withdraw(withdraw:any){
    this.bankService.Withdraw(withdraw);
    let transID=Math.floor(Math.random()*10)+100;
    let transObj=new Transaction(transID,"withdraw",withdraw.AccNo,withdraw.Balance);
    this.bankService.addTransaction(transObj);
    
  }
  
  ngOnInit() {
    
    this.bankService.fetchCustomer();
    this.customers=this.bankService.getCustomer();
  this.bankService.fetchTransaction();
  this.transactions=this.bankService.getTransaction();
}
}
