import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';
import { Customer } from '../EntityClasses/Customer';
import { Transaction } from '../EntityClasses/Transaction';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
bankService:BankServiceService;
customers: Customer[];
transactions: Transaction[];
  constructor(bankService:BankServiceService) {
    this.bankService=bankService;
   }

 
  Deposit(deposit:any){
    this.bankService.Deposit(deposit);
    let transID=Math.floor(Math.random()*10)+100;
    let transObj=new Transaction(transID,"deposit",deposit.AccNo,deposit.Balance);
    this.bankService.addTransaction(transObj);
    
  }
  ngOnInit() {
    this.bankService.fetchCustomer();
    this.customers=this.bankService.getCustomer();
    this.bankService.fetchTransaction();
    this.transactions=this.bankService.getTransaction();
  }

}
