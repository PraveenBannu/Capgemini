public class SeatNoNotValidException extends Exception {
    public SeatNoNotValidException(String mes){
        super(mes);
    }
}