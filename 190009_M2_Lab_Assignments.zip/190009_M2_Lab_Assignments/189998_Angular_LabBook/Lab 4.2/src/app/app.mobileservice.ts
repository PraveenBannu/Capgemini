import {Injectable} from '@angular/core';
import {Book} from './mobile';
import {HttpClient} from '@angular/common/http';
@Injectable({
    providedIn:'root'
})

export class BookService{
    //http:Http;
    constructor(private http:HttpClient){}

    getAllBookDetail(){
        return this.http.get('assets/booklist.json');
     
        //   return this.http.get('http://localhost:9090/SpringWithAngular/rest/employee');
        }
    searchBookData(data:number){
        return this.http.get('assets/booklist.json');
    }
}