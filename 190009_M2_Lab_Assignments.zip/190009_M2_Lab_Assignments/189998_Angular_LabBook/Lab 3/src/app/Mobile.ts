import {Camera} from './camera';
import {Prodavail} from './prodavail';
export class Mobile{
    mobId:number;
    mobName:string;
    mobPrice:number;
    type:string;
    cam:Camera;
    cat:string;
    prodava:Prodavail[];
    isValidFormSumitted:boolean;

}