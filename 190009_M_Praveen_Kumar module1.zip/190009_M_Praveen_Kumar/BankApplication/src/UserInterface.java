import java.util.Scanner;

public class UserInterface {

	public static void main(String a[]) {
		Scanner sc = new Scanner(System.in);
		int numOfEmployeees = sc.nextInt();
		String employees[] = new String[numOfEmployeees];
		for (int i = 0; i < numOfEmployeees; i++) {
			employees[i] = sc.next();
		}
		int count = 0;
		StringBuilder d = new StringBuilder();
		for (String s : employees) {
			String[] info = new String[2];
			info = s.split(",");
			info[1] = info[1].replaceAll(":", "");
			int num = Integer.parseInt(info[1]);
			if (num > 930) {
				count++;
				d.append(info[0] + " ");
			}
		}
		System.out.println(count + " " + d.toString() + "are late");

		sc.close();
	}

}