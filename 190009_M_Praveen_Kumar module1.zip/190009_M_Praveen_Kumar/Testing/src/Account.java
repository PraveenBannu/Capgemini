public class Account
{
 private int accId;
 private String accType;
 private int balance;
 
 public Account(int accountId,String accountType,int balance)
 {
 this.accId=accountId;
 this.accType=accountType;
 this.balance=balance;
 }
 public boolean deposit(int depositAmount){
 if(depositAmount<= 0)
 {
      return false;
 }
 else
 {
     balance=balance+depositAmount; 
     return true;
 }
 }
}