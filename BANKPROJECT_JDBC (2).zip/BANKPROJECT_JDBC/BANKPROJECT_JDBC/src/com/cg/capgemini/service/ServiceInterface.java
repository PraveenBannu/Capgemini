package com.cg.capgemini.service;

import java.sql.SQLException;
import com.cg.capgemini.bean.Account;
import com.cg.capgemini.exception.AccountNotFoundException;
import com.cg.capgemini.exception.InsufficientBalanceException;

public interface ServiceInterface {
	public abstract void CreateAccount(Account acc)throws SQLException;

	public void deposit(String accNo, double amt)
			throws AccountNotFoundException, SQLException;

	public void withDraw(String accNo, double amt)
			throws AccountNotFoundException, InsufficientBalanceException, SQLException;

	public void getBalance(String accNo) throws AccountNotFoundException,SQLException;

	public void fundTransfer(String accNo1, String accNo2, double amt)
			throws AccountNotFoundException, InsufficientBalanceException,SQLException;
	
	public void showTransaction(String accNo) throws AccountNotFoundException,SQLException;
	 
}