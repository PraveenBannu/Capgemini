package com.cg.capgemini.service;

import java.sql.SQLException;
import com.cg.capgemini.bean.Account;
import com.cg.capgemini.bean.Transaction;
import com.cg.capgemini.dao.AccountDao;
import com.cg.capgemini.exception.AccountNotFoundException;
import com.cg.capgemini.exception.InsufficientBalanceException;

public class ServiceImplementation implements ServiceInterface {

	AccountDao dao = new AccountDao();

	@Override
	public void CreateAccount(Account account) throws SQLException {
		try {
			account.setAccountNo(dao.createAccount(account));
		} catch (SQLException e) {
		throw e;
		}

	}

	@Override
	public void deposit(String accNo, double amt) throws AccountNotFoundException, SQLException {
		Account account = dao.getAccount(accNo);
		if (account == null)
			throw new AccountNotFoundException("Account not found............");
		else {
			dao.updateBalance(accNo, account.getBalance() + amt);
			dao.addTransaction(new Transaction(amt, "cr", "deposit", accNo));
		}

	}

	@Override
	public void withDraw(String accNo, double amt)
			throws AccountNotFoundException, InsufficientBalanceException, SQLException {
		Account account = dao.getAccount(accNo);
		if (account == null)
			System.out.println("No accounts found................");
		else {
			if (account.getBalance() > amt) {
				dao.updateBalance(accNo, account.getBalance() - amt);
				dao.addTransaction(new Transaction(amt, "DR", "Withdraw", accNo));
			} else {
				throw new InsufficientBalanceException("Insufficient Balance..........");
			}
		}

	}

	@Override
	public void getBalance(String accNo) throws AccountNotFoundException,SQLException {
		Account account;
		try {
			account = dao.getAccount(accNo);
			if (account == null)
				throw new AccountNotFoundException("NO Accounts Found...");
			else {
				System.out.println(account.getBalance());
			}
		} catch (SQLException e) {
			throw e;
		}

	}

	@Override
	public void fundTransfer(String accNo1, String accNo2, double amt)
			throws AccountNotFoundException, InsufficientBalanceException,SQLException {

		try {
			Account fromAccount = dao.getAccount(accNo1);
			Account toAccount = dao.getAccount(accNo2);
			if (fromAccount == null)
				throw new AccountNotFoundException("From Account Not Found........");
			if (toAccount == null)
				throw new AccountNotFoundException("To Account Not Found........");
			if (fromAccount.getBalance() < amt)
				throw new InsufficientBalanceException("Insufficient Balance..... Please Try Again.......");
			dao.updateBalance(accNo1, fromAccount.getBalance() - amt);
			dao.addTransaction(new Transaction(amt, "DR", "Fund Transfer", accNo1));
			dao.updateBalance(accNo2, toAccount.getBalance() + amt);
			dao.addTransaction(new Transaction(amt, "CR", "Fund Transfer", accNo2));
		} catch (SQLException e) {
			throw e;
		}

	}

	@Override
	public void showTransaction(String accNo) throws AccountNotFoundException ,SQLException{
		Account acc;
		try {
			acc = dao.getAccount(accNo);
			if (acc == null)
				System.out.println("No accounts found...............");
			System.out.println(dao.getTransactions(accNo));
		} catch (SQLException e) {
			throw e;
		}

	}
}
