package com.cg.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.capgemini.bean.Transaction;
import com.cg.capgemini.dao.ConnectionFactory;
import com.cg.capgemini.bean.Account;

public class AccountDao implements AccountDaoInterface {

	@Override
	public String createAccount(Account acc) throws SQLException {
		ConnectionFactory connectionFactory = ConnectionFactory.getInstance();
		Connection connection = connectionFactory.getConnection();
		String strSQL = "INSERT INTO Account(Accountnumber,name,phoneNo,address,balance,accountType) values(ACCNUMBER.nextval,?,?,?,?,?)";
		PreparedStatement statement = null;
		String accNo = null;
		try {
			statement = connection.prepareStatement(strSQL, new String[] { "ACCOUNTNUMBER" });
			statement.setString(1, acc.getName());
			statement.setString(2, acc.getPhoneNo());
			statement.setString(3, acc.getAddress());
			statement.setDouble(4, acc.getBalance());
			statement.setString(5, acc.getAccountType());
			if (statement.executeUpdate() > 0) {
				ResultSet rs = statement.getGeneratedKeys();
				while (rs.next())
					accNo = rs.getString(1);
			}

		} catch (SQLException e) {
			
			throw e;
		} finally {
			connection.close();
		}
		return accNo;

	}

	@Override
	public void updateBalance(String accNo, double bal) throws SQLException {
		String strSql = "UPDATE ACCOUNT SET BALANCE=? WHERE ACCOUNTNUMBER=?";
		ConnectionFactory connectionFactory = ConnectionFactory.getInstance();
		Connection connection = connectionFactory.getConnection();
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(strSql);
			statement.setDouble(1, bal);
			statement.setLong(2, Long.parseLong(accNo));
			if (statement.executeUpdate() > 0) {
				System.out.println("Balance Updated:" + bal);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			connection.close();
		}

	}

	@Override
	public void addTransaction(Transaction trans) throws SQLException {
		ConnectionFactory connectionFactory = ConnectionFactory.getInstance();
		Connection connection = connectionFactory.getConnection();
		String strSQL = "INSERT INTO TRANSACTION VALUES(TRANSEQ.nextval,?,?,?,?,SYSTIMESTAMP)";
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(strSQL);
			statement.setString(1, trans.getAccount());
			statement.setDouble(2, trans.getTransAmount());
			statement.setString(3, trans.getTransType());
			statement.setString(4, trans.getTransDescription());
			if (statement.executeUpdate() > 0) {

			}

		} catch (SQLException e) {
			throw e;
		} finally {
			connection.close();
		}

	}

	@Override
	public List<Transaction> getTransactions(String accNo) throws SQLException {
		List<Transaction> transactions = new ArrayList<>();
		ConnectionFactory connectionFactory = ConnectionFactory.getInstance();
		Connection connection = connectionFactory.getConnection();
		String strSQL = "select * from transaction where account = ?";
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(strSQL);
			statement.setString(1, accNo);
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next()) {
				Transaction trans = new Transaction();
				trans.setTransId(resultSet.getInt(1));
				trans.setAccount(resultSet.getString(2));
				trans.setTransAmount(resultSet.getDouble(3));
				trans.setTransType(resultSet.getString(4));
				trans.setTransDescription(resultSet.getString(5));
				trans.setTimestamp(resultSet.getTimestamp(6));
				transactions.add(trans);
			}

		} catch (SQLException e) {
			throw e;
		} finally {
			connection.close();
		}
		return transactions;
	}

	@Override
	public Account getAccount(String accNo) throws SQLException {
		Account account = null;
		ConnectionFactory connectionFactory = ConnectionFactory.getInstance();
		Connection connection = connectionFactory.getConnection();
		try {
			Long.parseLong(accNo);
		} catch (NumberFormatException e) {
			return null;
		}
		String strSQL = "select * from account where accountnumber = ?";
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(strSQL);
			statement.setString(1, accNo);
			ResultSet resultSet = statement.executeQuery();
			if (resultSet.next()) {
				account = new Account();
				account.setAccountNo(resultSet.getString(1));
				account.setName(resultSet.getString(4));
				account.setPhoneNo(resultSet.getString(5));
				account.setAddress(resultSet.getString(6));
				account.setBalance(resultSet.getDouble(3));
				account.setAccountType(resultSet.getString(2));
			}

		} catch (SQLException e) {
		
			throw e;
		} finally {
			connection.close();
		}
		return account;
	}
}
