package com.cg.capgemini.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.capgemini.bean.Transaction;
import com.cg.capgemini.bean.Account;

public interface AccountDaoInterface {

	String createAccount(Account acc) throws SQLException;

	void updateBalance(String accNo, double bal) throws SQLException;

	void addTransaction(Transaction trans) throws SQLException;

	List<Transaction> getTransactions(String accNo) throws SQLException;

	Account getAccount(String accNo) throws SQLException;

}
