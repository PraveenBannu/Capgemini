package com.cg.dao;

import java.util.Map;
import com.cg.bean.Account;

public interface AccountDao {

	void storeValuesIntoMap(Account account);

	Map<String, Account> displayAccount();
}
