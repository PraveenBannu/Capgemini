package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Account;

public class AccountDaoImpl implements AccountDao {

	public Map<String, Account> map = new HashMap<String, Account>();

	@Override
	public void storeValuesIntoMap(Account account) {
		map.put(account.getAccNo(), account);
		if (map.containsKey(account.getAccNo()))
			System.out.println("Account Number : " + map.get(account.getAccNo()).getAccNo());
	}

	@Override
	public Map<String, Account> displayAccount() {
		return map;
	}
}
