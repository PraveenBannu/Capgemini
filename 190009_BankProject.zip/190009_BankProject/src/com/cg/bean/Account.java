package com.cg.bean;

import java.util.ArrayList;
import java.util.List;

public class Account {

	private String accNo;
	private String accType;
	private double accbalance;
	private Customer customer;
	private List<Transaction> transaction = new ArrayList<>();

	public Account() {
		super();
	}

	public Account(String accNo, String accType, double accbalance, Customer customer, List<Transaction> transaction) {
		super();
		this.accNo = accNo;
		this.accType = accType;
		this.accbalance = accbalance;
		this.customer = customer;
		this.transaction = transaction;
	}

	public String getAccNo() {
		return accNo;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public double getAccbalance() {
		return accbalance;
	}

	public void setAccbalance(double accbalance) {
		this.accbalance = accbalance;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Transaction> getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction.add(transaction);
	}

	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", accType=" + accType + ", accbalance=" + accbalance + ", customer="
				+ customer + ", transaction=" + transaction + "]";
	}

	/*
	 * Random random = new Random(); long accNo = random.nextInt(1000000000);
	 */

}
