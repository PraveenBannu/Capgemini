package com.cg.service;

import java.util.Map;

import com.cg.bean.Account;
import com.cg.exception.AccountNotFoundException;
import com.cg.exception.InsufficientAmountException;

public interface Service {

	public void CreateAccount();
	public void ShowBalnce() throws AccountNotFoundException;
	public void deposite() throws AccountNotFoundException, InsufficientAmountException;
	public void withdraw() throws InsufficientAmountException, AccountNotFoundException;
	public void fundTransfer() throws AccountNotFoundException, InsufficientAmountException;
	public void printTransaction() throws AccountNotFoundException;
	public Map<String, Account> displayAccount();
}
