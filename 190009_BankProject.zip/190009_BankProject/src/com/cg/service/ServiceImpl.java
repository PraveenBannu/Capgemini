package com.cg.service;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.bean.Account;
import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.dao.AccountDaoImpl;
import com.cg.exception.AccountNotFoundException;
import com.cg.exception.InsufficientAmountException;

public class ServiceImpl implements Service {

	static Scanner scan = new Scanner(System.in);
	static int AN=1000;

	public static String getInput(String message) {
		System.out.println(message);
		String input = scan.nextLine();
		return input;
	}

	AccountDaoImpl accountDaoImpl = new AccountDaoImpl();

	@Override
	public void CreateAccount() {
		Account account = new Account();
		Customer customer = new Customer();
		customer.setName(getInput("Enter Name:"));
		customer.setPhoneNo(getInput("Enter Your PhoneNo:"));
		customer.setAddress(getInput("Enter Your Address:"));
		account.setAccNo(Integer.toString(AN++));
		account.setAccType(getInput("Enter Type:"));
		account.setAccbalance(Double.parseDouble(getInput("Enter Your Initial Balance:")));
		account.setCustomer(customer);
		accountDaoImpl.storeValuesIntoMap(account);
	}

	@Override
	public void ShowBalnce() throws AccountNotFoundException {
		System.out.println("Enter Account Number");
		String accNo = scan.nextLine();
		if (accountDaoImpl.map.containsKey(accNo)) {

			System.out.println(accountDaoImpl.map.get(accNo).getAccbalance());

		} else {
			throw new AccountNotFoundException("Account Not Found");
		}
	}

	@Override
	public void deposite() throws AccountNotFoundException, InsufficientAmountException {
		System.out.println("Enter Main Account Number:");
		String accNo = scan.nextLine();
		System.out.println("Enter Amount");
		int amount = Integer.parseInt(scan.nextLine());
		if (accountDaoImpl.map.containsKey(accNo)) {
			if (amount > 0) {
				Account account = accountDaoImpl.map.get(accNo);
				account.setAccbalance(amount + accountDaoImpl.map.get(accNo).getAccbalance());
				Transaction trans = new Transaction();
				trans.setTransAmount(amount);
				trans.setTransDescription("Deposit");
				trans.setTransType("Cash");
				account.setTransaction(new Transaction(amount, "cash"));
				System.out.println("Deposit Successfull");
				System.out.println("Total Balance is "+accountDaoImpl.map.get(accNo).getAccbalance());
			} else {
				throw new InsufficientAmountException("Account Not Found");
			}
		} else {
			throw new AccountNotFoundException("Account Not Found");
		}
	}

	@Override
	public void withdraw() throws InsufficientAmountException, AccountNotFoundException {
		System.out.println("Enter Main Account Number:");
		String accNo = scan.nextLine();
		System.out.println("Enter Amount");
		int amount = Integer.parseInt(scan.nextLine());
		if (accountDaoImpl.map.containsKey(accNo)) {
			if (amount > 0) {
				Account account = accountDaoImpl.map.get(accNo);
				account.setAccbalance(accountDaoImpl.map.get(accNo).getAccbalance() - amount);
				Transaction trans = new Transaction();
				trans.setTransAmount(amount);
				trans.setTransDescription("Deposit");
				trans.setTransType("Cash");
				account.setTransaction(new Transaction(amount, "cash"));
				System.out.println("Withdraw Successfull");
				System.out.println("Remaining Balance is "+accountDaoImpl.map.get(accNo).getAccbalance());

			} else {
				throw new InsufficientAmountException("Account Not Found");
			}
		} else {
			throw new AccountNotFoundException("Account Not Found");
		}
	}

	@Override
	public void fundTransfer() throws AccountNotFoundException, InsufficientAmountException {
		System.out.println("Enter Main account number:");
		String fromAccount = scan.nextLine();
		System.out.println("Enter Main Benificiary number:");
		String toAccount = scan.nextLine();
		System.out.println("Enter amount to be transfered:");
		int amount = scan.nextInt();
		if (accountDaoImpl.map.get(fromAccount).getAccbalance() > amount) {
			if (accountDaoImpl.map.containsKey(fromAccount)) {
				if (accountDaoImpl.map.containsKey(toAccount)) {
					accountDaoImpl.map.get(toAccount)
							.setAccbalance(amount + accountDaoImpl.map.get(toAccount).getAccbalance());
					Transaction trans2 = new Transaction();
					trans2.setTransAmount(amount);
					trans2.setTransDescription("FundTransfer");
					trans2.setTransType("Online");
					accountDaoImpl.map.get(fromAccount).setTransaction(trans2);
					accountDaoImpl.map.get(fromAccount)
							.setAccbalance(accountDaoImpl.map.get(fromAccount).getAccbalance() - amount);
				} else {
					throw new AccountNotFoundException("Account Not Found");
				}
				Transaction trans3 = new Transaction();
				trans3.setTransAmount(amount);
				trans3.setTransDescription("FundTransfer");
				trans3.setTransType("Online");
				accountDaoImpl.map.get(toAccount).setTransaction(trans3);
			    System.out.println("Fund transfered from " + accountDaoImpl.map.get(fromAccount).getAccNo() + " to "
			                        + accountDaoImpl.map.get(toAccount).getAccNo());
			                System.out.println("Account Balance in " + accountDaoImpl.map.get(fromAccount).getAccNo() + " is "
			                        + accountDaoImpl.map.get(fromAccount).getAccbalance());
			                System.out.println("Account Balance in " + accountDaoImpl.map.get(toAccount).getAccNo() + " account is "
			                        + accountDaoImpl.map.get(toAccount).getAccbalance());

			} else {
				throw new AccountNotFoundException("Account Not Found");
			}
		} else {
			throw new InsufficientAmountException("Account Not Found");
		}

	}

	@Override
	public void printTransaction() throws AccountNotFoundException {
		System.out.println("Enter Account Number:");
		String accNo = scan.nextLine();
		if (accountDaoImpl.map.containsKey(accNo)) {
			List<Transaction> transaction = accountDaoImpl.map.get(accNo).getTransaction();
			for (Transaction transactions : transaction) {

				System.out.println(transactions.getTransId() + "\t\t" + transactions.getTransAmount()+ "\t\t" +transactions.getTransType());
			}

		} else
			throw new AccountNotFoundException("Account Not Found");
	}

	@Override
	public Map<String, Account> displayAccount() {
		return accountDaoImpl.displayAccount();
	}
}
