package com.cg.capgemini.bean;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "jpaTransactions")
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int transId;
	private double transAmount;
	private String transType;
	private String transDescription;
	private Timestamp timestamp;
	@ManyToOne
	private Account account;

	public Transaction() {
		super();
		transAmount = 0;
		transType = null;
		transDescription = null;

	}

	public Transaction(double transAmount, String transType, String transDescription, Account account) {
		super();
		this.transAmount = transAmount;
		this.transType = transType;
		this.transDescription = transDescription;
		this.account = account;
		this.setTimestamp();

	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp() {
		this.timestamp = new Timestamp(System.currentTimeMillis());
	}

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public double getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(double transAmount) {
		this.transAmount = transAmount;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getTransDescription() {
		return transDescription;
	}

	public void setTransDescription(String transDescription) {
		this.transDescription = transDescription;
	}

	@Override
	public String toString() {
		return "Transaction [transId=" + transId + ", transAmount=" + transAmount + ", transType=" + transType
				+ ", transDescription=" + transDescription + ", timestamp=" + timestamp + ", account=" + account + "]";
	}

}
