package com.cg.capgemini.ui;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;
import com.cg.capgemini.bean.Account;
import com.cg.capgemini.exception.AccountNotFoundException;
import com.cg.capgemini.exception.InsufficientBalanceException;
import com.cg.capgemini.service.ServiceImplementation;

public class Main {
	static Scanner scan = new Scanner(System.in);

	public static String getInput(String message) {
		System.out.println(message);
		String input = scan.next();
		return input;
	}

	public static Account getAccount() {
		Account a1 = new Account();
		a1.setName(getInput("Enter Name"));
		a1.setPhoneNo(getInput("Enter Your PhoneNo."));
		a1.setAccountType(getInput("Enter Type"));
		a1.setAddress(getInput("Enter Your Address"));
		a1.setBalance(Double.parseDouble(getInput("Enter Your Initial Balance")));
		return a1;
	}

	public static void main(String[] args) {
		ServiceImplementation service = new ServiceImplementation();
		int choice = 0;
		while (choice != 20) {
			System.out.println("Welcome to Capgemini Bank");
			System.out.println("1- Create New Account ");
			System.out.println("2- Deposit");
			System.out.println("3- Withdraw Money");
			System.out.println("4- Show Balance");
			System.out.println("5- Fund Transfer");
			System.out.println("6- Print Transaction");
			System.out.println("7- Exit");
			System.out.println("Enter a choice");
			try {
				choice = Integer.parseInt(scan.next());
			} catch (NumberFormatException e1) {
				System.out.println("Wrong Choice/..");
				choice = 0;
			}
			switch (choice) {
			case 1:

				try {
					Account a1 = getAccount();
					service.CreateAccount(a1);
					System.out.println("Account Created Successfully...............\n" + "Name:" + a1.getName()
							+ "\nAccount Number:" + a1.getAccountNo() + "\nAccount Type:" + a1.getAccountType()
							+ "\nAddress:" + a1.getAddress());

				} catch (Exception e1) {
					// e1.printStackTrace();
					System.out.println("Error while creating an account........Please Try Again.........");
				}
				break;
			case 2:

				try {
					System.out.println("Enter Account Number: ");
					String Number = scan.next();
					System.out.println("Enter Amount to be Deposited: ");
					double amt;
					amt = Double.parseDouble(scan.next());
					service.deposit(Number, amt);
					System.out.println("Deposited successfully................");
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (SQLException e) {
					System.out.println("please Try Again...........");
				} catch (InputMismatchException e) {
					System.out.println("Input Mismatch please try Again............");
				} catch (Exception e1) {
					System.out.println("Something went wrong please try again.........");
				}

				break;

			case 3:
				String withAccNo = getInput("Enter Account Number");

				try {
					double withAmount = Double.parseDouble(getInput("Enter withraw amount"));
					service.withDraw(withAccNo, withAmount);
				} catch (AccountNotFoundException e1) {
					System.out.println(e1.getMessage());

				} catch (InsufficientBalanceException e1) {
					System.out.println(e1.getMessage());
				} catch (SQLException e) {
					System.out.println("please Try Again...........");
				} catch (InputMismatchException e) {
					System.out.println("Input Mismatch please try Again");
				} catch (NumberFormatException e1) {
					System.out.println("Wrong Inputs...............");
				} catch (Exception e1) {
					System.out.println("Something went wrong please try again.........");
				}
				break;
			case 4:

				String accNo = getInput("Enter Account Number");
				try {
					service.showBalance(accNo);
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (SQLException e) {
					System.out.println("Sorry... Something Went Wrong......");
				}

				break;
			case 5:

				try {
					String fromAccountNo = getInput("Give From Account Number ");
					String toAccountNo = getInput("Give To Account Number ");
					double transferAmount = Double.parseDouble(getInput("Amount To be Transferred "));
					if (!fromAccountNo.equals(toAccountNo)) {
						service.fundTransfer(fromAccountNo, toAccountNo, transferAmount);
						System.out.println(" fund-Transfer Successful...........");
					} else {
						System.out.println("From and To Acounts are same.............");
					}
				} catch (AccountNotFoundException e1) {
					System.out.println(e1.getMessage());

				} catch (InsufficientBalanceException e1) {
					System.out.println(e1.getMessage());
				} catch (Exception e) {
					System.out.println("please try again.............");
				}

				break;

			case 6:

				System.out.println("Give From Account Number to Print Transaction Report");
				String accT = scan.next();
				try {
					service.showTransaction(accT);
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (SQLException e) {
					System.out.println("Sorry... Something Went Wrong......");
				}

				break;

			default:
				System.out.println("Wrong Input Entered............");

			}

		}
		scan.close();
	}
}
