package com.cg.capgemini.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.cg.capgemini.bean.Transaction;
import com.cg.capgemini.bean.Account;

public interface AccountDaoInterface {

	public Account createAccount(Account account);

	public double updateBalance(Account account);

	public Account getAccount(String accountNo);
}
