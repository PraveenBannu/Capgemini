package com.cg.capgemini.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.capgemini.bean.Account;

public class AccountDao implements AccountDaoInterface {

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager entityManager = factory.createEntityManager();

	@Override
	public Account createAccount(Account account) {
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		return account;

	}

	@Override
	public double updateBalance(Account account) {
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		return account.getBalance();
	}

	@Override
	public Account getAccount(String accountNo) {
		Account account = entityManager.find(Account.class, Long.parseLong(accountNo));
		return account;
	}

}
