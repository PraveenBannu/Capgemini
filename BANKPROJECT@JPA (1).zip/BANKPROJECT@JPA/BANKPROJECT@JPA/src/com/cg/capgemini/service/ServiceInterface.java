package com.cg.capgemini.service;

import java.sql.SQLException;
import java.util.Map;
import com.cg.capgemini.bean.Account;
import com.cg.capgemini.exception.AccountNotFoundException;
import com.cg.capgemini.exception.InsufficientBalanceException;

public interface ServiceInterface {
	public abstract void CreateAccount(Account account) throws SQLException;

	public void deposit(String accountNo, double amount) throws AccountNotFoundException, SQLException;

	public void withDraw(String accountNo, double amount)
			throws AccountNotFoundException, InsufficientBalanceException, SQLException;

	public void showBalance(String accountNo) throws AccountNotFoundException, SQLException;

	public void fundTransfer(String fromAccount, String toAccount, double amount)
			throws AccountNotFoundException, InsufficientBalanceException, SQLException;

	public void showTransaction(String accountNo) throws AccountNotFoundException, SQLException;

}