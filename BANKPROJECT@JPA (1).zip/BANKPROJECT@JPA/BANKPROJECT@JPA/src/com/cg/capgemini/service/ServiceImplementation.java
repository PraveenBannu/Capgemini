package com.cg.capgemini.service;

import java.sql.SQLException;

import com.cg.capgemini.bean.Account;
import com.cg.capgemini.bean.Transaction;
import com.cg.capgemini.dao.AccountDao;
import com.cg.capgemini.exception.AccountNotFoundException;
import com.cg.capgemini.exception.InsufficientBalanceException;

public class ServiceImplementation implements ServiceInterface {

	AccountDao dao = new AccountDao();

	@Override
	public void CreateAccount(Account account) throws SQLException {

		dao.createAccount(account);

	}

	@Override
	public void deposit(String accountNo, double amount) throws AccountNotFoundException, SQLException {
		Account account = dao.getAccount(accountNo);
		if (account == null)
			throw new AccountNotFoundException("Account Not Found........Please try Again....");
		else {
			account.setBalance(account.getBalance() + amount);

			account.getTrans().add(new Transaction(amount, "CR", "deposit", account));
			dao.updateBalance(account);
		}

	}

	@Override
	public void withDraw(String accountNo, double amount)
			throws AccountNotFoundException, InsufficientBalanceException, SQLException {
		Account account = dao.getAccount(accountNo);
		if (account == null)
			throw new AccountNotFoundException("Account Not Found........Please try Again....");
		else {
			if (account.getBalance() > amount) {
				account.setBalance(account.getBalance() - amount);
				account.getTrans().add(new Transaction(amount, "DR", "Withdraw", account));
				dao.updateBalance(account);
				System.out.println("Amount Withdrawn successful................");
			} else {
				throw new InsufficientBalanceException("Insufficient Balance..........");
			}
		}

	}

	@Override
	public void showBalance(String accountNo) throws AccountNotFoundException, SQLException {
		Account account;
		account = dao.getAccount(accountNo);
		if (account == null)
			throw new AccountNotFoundException("Account Not Found........Please try Again....");
		else {
			System.out.println(account.getBalance());
		}

	}

	@Override
	public void fundTransfer(String fromAccountNo, String toAccountNo, double amount)
			throws AccountNotFoundException, InsufficientBalanceException, SQLException {

		Account fromAccount = dao.getAccount(fromAccountNo);
		Account toAccount = dao.getAccount(toAccountNo);
		if (fromAccount == null)
			throw new AccountNotFoundException("Account Number: " + fromAccountNo + "Not Found");
		if (toAccount == null)
			throw new AccountNotFoundException("Account Number: " + toAccountNo + "Not Found");
		if (fromAccount.getBalance() < amount)
			throw new InsufficientBalanceException("Insufficient Balance............");
		fromAccount.setBalance(fromAccount.getBalance() - amount);

		fromAccount.getTrans().add(new Transaction(amount, "DR", "Fund Transfer", fromAccount));
		dao.updateBalance(fromAccount);
		toAccount.setBalance(toAccount.getBalance() + amount);

		toAccount.getTrans().add(new Transaction(amount, "CR", "Fund Transfer", toAccount));
		dao.updateBalance(toAccount);

	}

	@Override
	public void showTransaction(String accountNo) throws AccountNotFoundException, SQLException {
		Account account;

		account = dao.getAccount(accountNo);
		if (account == null)
			throw new AccountNotFoundException("Account Not Found........Please try Again....");
		else
			System.out.println(account.getTrans());
	}

}
