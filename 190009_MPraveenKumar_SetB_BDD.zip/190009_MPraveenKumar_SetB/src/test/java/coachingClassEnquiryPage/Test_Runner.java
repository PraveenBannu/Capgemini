package coachingClassEnquiryPage;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

// TestRunner using cucumber.feature...
@RunWith(Cucumber.class)
@CucumberOptions(features = {"src/test/resources/coachingClassEnquiry"},dryRun=false,glue="coachingClassEnquiryPage")
public class Test_Runner {

}
