package coachingClassEnquiryPage;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.CoachingClassBeanPagefactory;

public class CoachingClassStepDefinition {
	
	// Using WebDriver...
	private WebDriver driver;
	private CoachingClassBeanPagefactory coachingClassPageFactory;

	// Using the ChromeDriver path....
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\capgemini\\Module 4\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	 // Usage of html path...
	@Given("^User is on 'Enquiry form' page$")
	public void user_is_on_Enquiry_form_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		driver.get("C:\\capgemini\\Module 4\\190009_MPraveenKumar_SetB\\target\\Coaching_Class_Enquiry.html");
		coachingClassPageFactory = new CoachingClassBeanPagefactory(driver);
	}

	// Verifying the title of the page...
	@Then("^'Verifying the title of the page'$")
	public void verifying_the_title_of_the_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String expectedMessage = "Online Coaching Class Enquiry Form";
		String actualMessage = driver.getTitle();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(15000);
		driver.close();
	}

	// Verifying the text on page...
	@Then("^'Verifying the text on page'$")
	public void verifying_the_text_on_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String bodyText = driver.findElement(By.tagName("body")).getText();
		Assert.assertTrue("Text not found!", bodyText.contains("Shree Coaching Classes Enquiry"));
		driver.close();
	}
	
	// When the user types invalid firstName...
	@When("^user enters invalid firstname$")
	public void user_enters_invalid_firstname() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		coachingClassPageFactory.setFirstName("");
		coachingClassPageFactory.setSubmitButton();
	}

	// When the user enters invalid firstName then it shows that the firstName should be filled...
	@Then("^display message 'First Name must be filled out'$")
	public void display_message_First_Name_must_be_filled_out() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String expectedmessage = "First Name must be filled out";
		String actualmessage = driver.switchTo().alert().getText();
		Assert.assertEquals(actualmessage, expectedmessage);
		Thread.sleep(15000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	// When the user types invalid lastName...
	@When("^user enters invalid lastname$")
	public void user_enters_invalid_lastname() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		coachingClassPageFactory.setFirstName("Praveen");
		coachingClassPageFactory.setLastName("");
		coachingClassPageFactory.setSubmitButton();
	}

	// When the user enters invalid lastName then it shows that the lastName should be filled...
	@Then("^display message 'Last Name must be filled out'$")
	public void display_message_Last_Name_must_be_filled_out() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String expectedmessage = "Last Name must be filled out";
		String actualmessage = driver.switchTo().alert().getText();
		Assert.assertEquals(actualmessage, expectedmessage);
		Thread.sleep(15000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	// When the user types invalid emailName...
	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		coachingClassPageFactory.setFirstName("Praveen");
		coachingClassPageFactory.setLastName("Mallipudi");
		coachingClassPageFactory.setEmail("");
		coachingClassPageFactory.setSubmitButton();

	}

	// When the user enters invalid Email then it shows that the Email should be filled...
	@Then("^displays message 'Email must be filled out'$")
	public void displays_message_Email_must_be_filled_out() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String expectedmessage = "Email must be filled out";
		String actualmessage = driver.switchTo().alert().getText();
		Assert.assertEquals(actualmessage, expectedmessage);
		Thread.sleep(15000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	// When the user types invalid MobileNumber...
	@When("^user enters invalid Mobile Number$")
	public void user_enters_invalid_Mobile_Number() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		coachingClassPageFactory.setFirstName("Praveen");
		coachingClassPageFactory.setLastName("Mallipudi");
		coachingClassPageFactory.setEmail("mallipudipraveen258@gmail.com");
		coachingClassPageFactory.setMobileNumber("");
		coachingClassPageFactory.setSubmitButton();
	}

	// When the user enters invalid MobileNumber then it shows that the MobileNumber should be filled...
	@Then("^displays 'Mobile must be filled out'$")
	public void displays_Mobile_must_be_filled_out() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String expectedMessage = "Mobile must be filled out";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(15000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	// When the user enters the alphabetic letters in MobileBox it should show that enter numeric values...
	@When("^user enters alphabetic Mobile Number$")
	public void user_enters_alphabetic_Mobile_Number() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		coachingClassPageFactory.setFirstName("Praveen");
		coachingClassPageFactory.setLastName("Mallipudi");
		coachingClassPageFactory.setEmail("mallipudipraveen258@gmail.com");
		coachingClassPageFactory.setMobileNumber("qwert");
		coachingClassPageFactory.setSubmitButton();
	}

	// Entering numeric values in MobileBar...
	@Then("^displays 'Enter numeric value'$")
	public void displays_Enter_numeric_value() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String expectedMessage = "Enter numeric value";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(15000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	// Whenever the user enters Invalid mobile number...
	@When("^user enters Invalid Mobile Number$")
	public void user_enters_Invalid_Mobile_Number() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		coachingClassPageFactory.setFirstName("Praveen");
		coachingClassPageFactory.setLastName("Mallipudi");
		coachingClassPageFactory.setEmail("mallipudipraveen258@gmail.com");
		coachingClassPageFactory.setMobileNumber("23546");
		coachingClassPageFactory.setSubmitButton();
	}

	// Entering 10 digit Mobile Number...
	@Then("^displays 'Enter (\\d+) digit Mobile number'$")
	public void displays_Enter_digit_Mobile_number(int arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		
		String expectedMessage = "Enter 10 digit Mobile number";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(15000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters wrong Mobile Number$")
	public void user_enters_wrong_Mobile_Number() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		coachingClassPageFactory.setFirstName("Praveen");
		coachingClassPageFactory.setLastName("Mallipudi");
		coachingClassPageFactory.setEmail("mallipudipraveen258@gmail.com");
		coachingClassPageFactory.setMobileNumber("3521479630");
		coachingClassPageFactory.setSubmitButton();
	}

	// Here the user clicks the Submit button after entering the details...
	@When("^user clicks 'Submit' button$")
	public void user_clicks_Submit_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		coachingClassPageFactory.setFirstName("Praveen");
		coachingClassPageFactory.setLastName("Mallipudi");
		coachingClassPageFactory.setEmail("mallipudipraveen258@gmail.com");
		coachingClassPageFactory.setMobileNumber("7093582238");
		coachingClassPageFactory.setTutionType("Spoken English");
		coachingClassPageFactory.setCity("Pune");
		coachingClassPageFactory.setLearningMode("Class room training");
		coachingClassPageFactory.setSubmitButton();
	}

	// It shows that the Enquiry details should be filled...
	@Then("^displays 'Enquiry details must be filled out'$")
	public void displays_Enquiry_details_must_be_filled_out() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String expectedMessage = "Enquiry details must be filled out";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(15000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	// User clicks the submit your request button...
	@When("^user clicks 'Submit your request' button$")
	public void user_clicks_Submit_your_request_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		coachingClassPageFactory.setFirstName("Praveen");
		coachingClassPageFactory.setLastName("Mallipudi");
		coachingClassPageFactory.setEmail("mallipudipraveen258@gmail.com");
		coachingClassPageFactory.setMobileNumber("7093582238");
		coachingClassPageFactory.setTutionType("Spoken English");
		coachingClassPageFactory.setCity("Pune");
		coachingClassPageFactory.setLearningMode("Class room training");
		coachingClassPageFactory.setEnquiryTextBox("Info regarding Classes");
		coachingClassPageFactory.setSubmitButton();
	}

	// After clicking the submit button it shows that Thank you for submitting the online coaching Class enquiry through alert box... 
	@Then("^displays 'Thank you for submitting the online coaching Class Enquiry'$")
	public void displays_Thank_you_for_submitting_the_online_coaching_Class_Enquiry() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String expectedMessage = "Thank you for submitting the online coaching Class Enquiry";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(15000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	// Whenever the user clicks the alert box message...
	@When("^user clicks 'Alert box message'$")
	public void user_clicks_Alert_box_message() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().accept();
	}

	// Then it will display that Our counselor will contact you soon...
	@Then("^displays 'Our Counselor will contact you soon'$")
	public void displays_Our_Counselor_will_contact_you_soon() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String bodyText = driver.findElement(By.tagName("body")).getText();
		Assert.assertTrue("Text not found!", bodyText.contains("Our Counselor will contact you soon."));
		Thread.sleep(15000);
		driver.close();
	}
}
